rZ9HW4

TFS: http://smlmsvsd01:8000/tfs/net/BIGTRONS
http://smlmstfd01:80

SMLBIGTDBP01
Debug
D3bu6

DB Config
=========
Go to: [web_address]/DBConfig
Access Password		: (password to change the config)
Server Name		: SMLMSVSD01\MSSQLSERVER2008
			  SMLMSSQD01
Database Name		: BIGTRONS
Database User Name	: BIGTRONS
Database Password	: B16Tr0n5

Jika lupa Access Password, buka folder project, cari file Config.ini, hapus. Lalu masukkan password baru.

Table Naming
============
M - Master
T - Transaction
D - Detail of Master or Transaction
S - Setting
C - Detail of Setting

Stored Procedure Naming:
========================
del_[TABLENAME]		: delete data on table by Primary Key
del_[TABLENAME]_BC	: delete data on table by Criteria
ins_[TABLENAME]		: insert data on table by all fileds
sel_[TABLENAME]		: select data on table by Primary Key
sel_[TABLENAME]_BC	: select data on table by Criteria
upd_[TABLENAME]		: update data on table by Primary Key
upd_[TABLENAME]_BC	: update data on table by Criteria

MVVM
====
Model
-----
Representasi dari table di DB. Nama Model sama dengan nama table.

Class [TABLENAME], berisi Properties yang merupakan representasi dari fields di table. diubah jika field pada table berubah.

ModelDA
-------
Class [TABLENAME]DA, berisi Methods Logic untuk akses data table.
Secara default ada 7 methods:
- Insert : untuk insert data pada table
- Select : select data pada table by Primary Key
- Update : update data pada table by Primary Key
- Delete : delete data pada table by Primary Key
- SelectBC : select data pada table by Criteria
- UpdateBC : update data pada table by Criteria
- DeleteBC : delete data pada table by Criteria

View
----
GUI di mana user akan berinteraksi dengan system. Nama View sama dengan nama table, tanpa inisial jenis table (M, T, D, S, C)

Secara standard ada 7 view (dan partial view, partial view ditandai dengan tanda underscore _):
1. Index : view paling utama, tempat partial view akan disisipkan
2. _List : partial view untuk menampilkan list data pada halaman depan saat view pertama kali dibuka
3. _Form : partial view untuk menampilkan data detail maupun untuk input dan edit data
4. _ButtonAdd : partial view untuk menentukan tombol apa aja yang akan ditampilkan pada partial view _Form untuk action Add
5. _ButtonDetail : partial view untuk menentukan tombol apa aja yang akan ditampilkan pada partial view _Form untuk action Detail
6. _ButtonUpdate : partial view untuk menentukan tombol apa aja yang akan ditampilkan pada partial view _Form untuk action Update
7. _Browse : partial view untuk popup browsing data

ViewModel
---------
Class mapper antara Model dan View. Nama ViewModel adalah [TABLENAME]VM dengan tanpa inisial jenis table (M, T, D, S, C).
Yang perlu diubah/ disesuaikan dengan kebutuhan hanya bagian Property dan method Mapping.
Property adalah field apa saja yang akan kita tampilkan pada View.
Method Mapping berfungsi untuk memetakan Property dengan field sesungguhnya di table.

Controller
----------
Business Logic dari system. Nama Controller adalah [TABLENAME]Controller dengan tanpa inisial jenis table (M, T, D, S, C).

Method standard:
1. IsSaveValid : untuk validasi data yang di-input
2. Index : untuk mengatur view Index
3. List : untuk mengatur partial view _List
4. Read : untuk menampilkan data pada list di partial view _List
5. Browse: untuk menampilkan data pada list di partial view _Browse
6. Add : untuk mengatur partial view untuk action Add
7. Detail : untuk mengatur partial view untuk action Detail
8. Update : untuk mengatur partial view untuk action Update
9. Delete : logic untuk action Delete
10. Save : logic untuk Save, baik untuk action add maupun update
11. Browse[TABLENAME] dengan tanpa inisial jenis table (M, T, D, S, C) : untuk mengatur partial view _Browse
